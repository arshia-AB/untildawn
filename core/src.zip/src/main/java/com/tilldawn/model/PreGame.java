package com.tilldawn.model;

public class PreGame {
    private String hero;
    private int duration;
}
