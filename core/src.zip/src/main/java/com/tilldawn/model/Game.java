package com.tilldawn.model;

public class Game {
    private int timePassed = 0;

    public int getTimePassed() {
        return timePassed;
    }

    public void setTimePassed(int timePassed) {
        this.timePassed = timePassed;
    }
}
