package com.tilldawn.model;

public record Result(boolean IsSuccess, String Message) {

}
